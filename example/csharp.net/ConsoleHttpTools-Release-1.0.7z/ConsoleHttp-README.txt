README.txt for ConsoleHttpPost.exe and ConsoleHttpGet.exe

Command line usage:

> ConsoleHttpPost
	That basic command will look in the current directory for a configuration file named "ConfigPOST.xml"

> ConsoleHttpPost {path to config file name}
Example:
> ConsoleHttpPost config/ConfigPOST-Silver-20Kjpg.xml
	Will load the specified file and do a POST based on the properties set in the config file passed.
	Log files and generated files will be saved in the "./console_POST" directory

ConsoleHttpGet application looks for a configuration file named "ConfigGET.xml" and outputs to "./console_GET", 
	following the same pattern as POST
	
See the included ConfigGET.xml and ConfigPOST.xml, both have comments for each of the properties that can be configured.
Also see the included directory named "Config" for many different configuration files.
By using many configuration files you can setup POST and GET on the various servers with different URLs, simply,
	with a single command line for each.